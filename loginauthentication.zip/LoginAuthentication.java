/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class LoginAuthentication {
    public static void main(String[] args) {
        String Name = "Sirisha";
        int id = 1234;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of the user: ");
        String name = sc.nextLine();
        System.out.println("Enter the id Number: ");
        int ID = sc.nextInt();
        try {
            if (!Name.equals(name) || id != ID) {
                throw new ArithmeticException("Invalid Login Credentials");
            }
            System.out.println("Login Successfully");

        } catch (Exception e) {
            System.out.println("Exception Handled");
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Program Ended");
        }

        sc.close();
    }
}



